int main()
{
float s;

printf("abc");
}
