 
#include<stdio.h> int main() {
 int a, b=10, c;
printf("Enter a \n");
scanf("%d", &a);
3**/
c = a + b;

printf("Result: %d\n", c);
printf();
 
}

