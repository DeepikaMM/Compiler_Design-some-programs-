 /*
  * {}.@other symbols
  **/
#include<stdio.h> //including standard library
int main() // function /* main */
{
 //how about//this?
int a, b=10, c;
printf("Enter a \n");
scanf("%d", &a);
/**calculate varaible **/3**/
c = a + b;
"//printing result"
printf("Result: %d\n", c);
printf("/* hi */");
 "/* now we /* try this */"
}
/* 
// End of Function : Total no of valid comments : 7
**/
